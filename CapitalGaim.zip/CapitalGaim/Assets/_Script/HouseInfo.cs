﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class HouseInfo : MonoBehaviour
{
    public Properties properties;

    public TextMeshProUGUI salePriceText;
    public TextMeshProUGUI cashflowText;
    public TextMeshProUGUI rentCostText;

    public int cashflow;
    public int rentCost;
    public int salePrice;
    public bool isbought;

    void Update()
    {
        salePrice = properties.price;
        cashflow = properties.cashflow;
        rentCost = properties.costToRent;
        isbought = properties.isBought;

        cashflowText.text = "Cashflow:\n$" + cashflow.ToString();
        rentCostText.text = "Rent Cost:\n$" + rentCost.ToString();
        salePriceText.text = "Sale Price:\n$" + salePrice.ToString();
    }


}
