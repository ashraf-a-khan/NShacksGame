﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "New Property", menuName = "Properties")]
public class Properties : ScriptableObject
{
    public int price;
    public int cashflow;
    public int costToRent;
    public bool isBought = false;

    public int AddCash()
    {
        return cashflow;
    }

    public int SubtractPrice()
    {
        return price;
    }

    public int SubtractCash()
    {
        return costToRent;
    }
    
    public bool BuyHouse(GameObject salePriceText, Properties properties)
    {
        salePriceText.SetActive(false);
        isBought = true;
        return isBought;
    }
}
