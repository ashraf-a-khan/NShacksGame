﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform target;
    public float target_Offset;
    private void Start()
    {
        target_Offset = transform.position.x - target.position.y;
    }
    void Update()
    {
        if (target)
        {
            transform.position = new Vector3(target.transform.position.x + target_Offset, transform.position.y, transform.position.z);
        }
    }
}
