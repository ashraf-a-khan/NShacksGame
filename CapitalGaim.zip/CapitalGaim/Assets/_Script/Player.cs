﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class Player : MonoBehaviour
{
    public float runningSpeed;
    public Rigidbody2D rb;
    public Animator myAnimator;

    public GameObject salePriceCanvas;
    public GameObject houseStatsCanvas;
    public List<GameObject> housesOwned = new List<GameObject>();

    private static Player instance;

    // Singleton so you can call it from other scripts
    public static Player Instance
    {
        get
        {
            if (instance == null)
            {
                instance = GameObject.FindObjectOfType<Player>();
            }
            return Player.instance;
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        myAnimator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        PlayerMovement();
        FlipPlayer();
        StartCoroutine(GetCashflow());
    }

    private void PlayerMovement()
    {
        Vector2 movementHorizontal = new Vector2(Input.GetAxis("Horizontal") * runningSpeed, rb.velocity.y);
        rb.velocity = movementHorizontal;
        bool playerHasHorizontalVelocity = Mathf.Abs(rb.velocity.x) > Mathf.Epsilon;
        myAnimator.SetBool("Running", playerHasHorizontalVelocity);
    }

    private void FlipPlayer()
    {
        // Creates a bool whether the player has any horizontal movement at all, return true if it does
        bool playerHasHorizontalMovement = Mathf.Abs(rb.velocity.x) > Mathf.Epsilon;
        if (playerHasHorizontalMovement)
        {
            // Sets the scale of the player to be a new vector2 where the x axis is equal to the sign (-1, +1) of the velocity on its x axis
            transform.localScale = new Vector2(Mathf.Sign(rb.velocity.x), 1);
        }
    }

    public IEnumerator GetCashflow()
    {
        yield return new WaitForSeconds(10f);
        AddCash();
    }

    private void AddCash()
    {
        for (int i = 0; i < housesOwned.Count; i++)
        {
            GameManager.Instance.cashOnHand += housesOwned[i].gameObject.GetComponent<HouseInfo>().properties.cashflow - housesOwned[i].gameObject.GetComponent<HouseInfo>().properties.costToRent;
        }
    }

    void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("House"))
        {
            HouseInfo houseInfo = other.gameObject.GetComponent<HouseInfo>();
            salePriceCanvas = houseInfo.gameObject.transform.GetChild(0).gameObject;
            houseStatsCanvas = houseInfo.gameObject.transform.GetChild(1).gameObject;
            Debug.Log(houseInfo);
            if ((Input.GetKeyUp(KeyCode.Space) && other.CompareTag("House")) && (GameManager.Instance.cashOnHand >= houseInfo.salePrice) && houseInfo.properties.isBought == true)
            {
                GameManager.Instance.cashOnHand -= houseInfo.salePrice;
                houseInfo.properties.BuyHouse(salePriceCanvas, houseInfo.properties);
                housesOwned.Add(houseInfo.gameObject);
                houseStatsCanvas.SetActive(true);
            }
        }
    }
}
